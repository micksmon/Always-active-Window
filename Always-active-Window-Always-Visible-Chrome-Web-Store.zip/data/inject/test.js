console.log('This is a test injection check of "Always active Window" extension.');
